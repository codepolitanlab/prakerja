self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "c7303908eba6393d9bee",
    "url": "/css/about.bdd6c97d.css"
  },
  {
    "revision": "539b88bda526b1dcd1d8",
    "url": "/css/app.ad3a3bab.css"
  },
  {
    "revision": "30d8ef7b0944092a51ff",
    "url": "/css/chunk-vendors.64d43e69.css"
  },
  {
    "revision": "1460dbd319db0f4f1494441cf3250eee",
    "url": "/img/Bukalapak-1.1460dbd3.webp"
  },
  {
    "revision": "b3ab3ddc1972e7cae22da981526bd268",
    "url": "/img/Lebih_Cepat.b3ab3ddc.webp"
  },
  {
    "revision": "4ca9548178a83bc001d38e5227a3709f",
    "url": "/img/Logo-kartu-prakerja.4ca95481.webp"
  },
  {
    "revision": "c9953c50aed833e03ec737378f4fe272",
    "url": "/img/Study-Kasus.c9953c50.webp"
  },
  {
    "revision": "f9fa2907a322de654cddc0b3f0baea48",
    "url": "/img/Tentukan_Waktu_Sendiri.f9fa2907.webp"
  },
  {
    "revision": "684add1f5c6fe384bedb95719359b843",
    "url": "/img/img-mentoring.684add1f.png"
  },
  {
    "revision": "4fafef4c93355504f47b710b8f25838a",
    "url": "/img/kamu.4fafef4c.webp"
  },
  {
    "revision": "4c2227cd8e8bcabdccb115b818513746",
    "url": "/img/logo-cp.4c2227cd.webp"
  },
  {
    "revision": "b32785a88822b6b636fdb8641df1bf6f",
    "url": "/img/prakerja-about.b32785a8.webp"
  },
  {
    "revision": "77b5c714a7d105cc9088a0deb04ec4c1",
    "url": "/img/prakerja.77b5c714.webp"
  },
  {
    "revision": "78fa78971693316b924f6b8065680b29",
    "url": "/img/share.jpg"
  },
  {
    "revision": "7ed54399ae2de9b416de56df02968f9e",
    "url": "/img/tokopedia.7ed54399.webp"
  },
  {
    "revision": "f3b5449568da4b36d75069edd4289017",
    "url": "/index.html"
  },
  {
    "revision": "c7303908eba6393d9bee",
    "url": "/js/about.fd55a816.js"
  },
  {
    "revision": "539b88bda526b1dcd1d8",
    "url": "/js/app.f0eb2f98.js"
  },
  {
    "revision": "30d8ef7b0944092a51ff",
    "url": "/js/chunk-vendors.5472d5d6.js"
  },
  {
    "revision": "2e7164384ed165c2be6218ab583ac5cc",
    "url": "/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  }
]);